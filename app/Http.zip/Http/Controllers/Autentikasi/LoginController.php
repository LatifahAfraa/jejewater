<?php

namespace App\Http\Controllers\Autentikasi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Hash;
use Session;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        $data = User::where('username', $request->username)->firstOrfail();
        if ($data) {
            if (Hash::check($request->password, $data->password)) {
                session(['berhasil_login' => true]);

                Session::put('id_user', $data->id_user);
                Session::put('username', $data->username);
                Session::put('password', $data->password);
                Session::put('role', $data->role);
                Session::put('nama', $data->nama);

                if (Session::get('role') == 1) {
                    $sopir = DB::table('supir')->count();
                    $mobil = DB::table('mobil')->count();
                    $ban   = DB::table('ban')->count();
                    $aksi  = DB::table('ban')
                        ->leftjoin('type_ban', 'ban.id_type', 'type_ban.id_type')
                        ->leftjoin('status_ban', 'ban.id_status', 'status_ban.id_status')
                        ->leftjoin('kondisi_ban', 'ban.id_kondisi', 'kondisi_ban.id_kondisi')
                        ->leftjoin('merk_ban', 'ban.merk_ban_id', 'merk_ban.merk_ban_id')
                        ->select('ban.*', 'type_ban.*', 'status_ban.*', 'kondisi_ban.*', 'merk_ban.*')
                        ->get();
                    return view('admin.home', compact('sopir', 'mobil', 'ban', 'aksi'));
                }
            }
        }
        return redirect('/')->with('message', 'Email atau Password Salah');
    }

    public function logout(Request $request)
    {
        $request->session()->flush();
        return redirect('/');
    }
}
