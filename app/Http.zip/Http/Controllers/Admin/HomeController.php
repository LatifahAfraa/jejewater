<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function index()
    {
        $sopir = DB::table('supir')->count();
        $mobil = DB::table('mobil')->count();
        $ban   = DB::table('ban')->count();
        $aksi  = DB::table('ban')
            ->leftjoin('type_ban', 'ban.id_type', 'type_ban.id_type')
            ->leftjoin('status_ban', 'ban.id_status', 'status_ban.id_status')
            ->leftjoin('kondisi_ban', 'ban.id_kondisi', 'kondisi_ban.id_kondisi')
            ->leftjoin('merk_ban', 'ban.merk_ban_id', 'merk_ban.merk_ban_id')
            ->select('ban.*', 'type_ban.*', 'status_ban.*', 'kondisi_ban.*', 'merk_ban.*')
            ->get();

        return view('admin.home', compact('sopir', 'mobil', 'ban', 'aksi'));
    }

    public function add($id_ban)
    {
        $mobil = DB::table('mobil')->get();
        $sopir = DB::table('supir')->get();
        $ban   = DB::table('ban')
            ->leftjoin('type_ban', 'ban.id_type', 'type_ban.id_type')
            ->leftjoin('status_ban', 'ban.id_status', 'status_ban.id_status')
            ->leftjoin('kondisi_ban', 'ban.id_kondisi', 'kondisi_ban.id_kondisi')
            ->leftjoin('merk_ban', 'ban.merk_ban_id', 'merk_ban.merk_ban_id')
            ->select('ban.*', 'type_ban.*', 'status_ban.*', 'kondisi_ban.*', 'merk_ban.*')
            ->where('id_ban', $id_ban)
            ->first();

        return view('admin.manajemen.pasangban', compact('mobil', 'ban', 'sopir'));
    }

    public function pasang(Request $request, $id_ban)
    {
        $validation = $request->validate([
            'id_ban' => 'required',
            'id_mobil' => 'required',
            'id_supir' => 'required',
        ]);

        $data =  DB::table('kendaraan')
            ->insert([
                'id_ban' => $request->id_ban,
                'id_mobil' => $request->id_mobil,
                'id_supir' => $request->id_supir,

            ]);
        $data =  DB::table('ban')
            ->where('id_ban', $id_ban)
            ->update([
                'id_status' => 2,

            ]);
        if ($data) {
            return redirect()->route('home')->with('success', 'Berhasil, Ban Telah Terpasang');
        } else {
            return redirect()->route('home')->with('error', 'Gagal');
        }
    }
}
