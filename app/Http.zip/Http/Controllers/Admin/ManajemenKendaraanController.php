<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManajemenKendaraanController extends Controller
{
    public function index()
    {
        $kendaraan = DB::table('kendaraan')
            ->leftjoin('mobil', 'kendaraan.id_mobil', 'mobil.id_mobil')
            ->leftjoin('supir', 'kendaraan.id_supir', 'supir.id_supir')
            ->select('kendaraan.*', 'mobil.*', 'supir.*')
            ->paginate(10);

        return view('admin.manajemen.manajemenmobil', compact('kendaraan'));
    }

    public function add()
    {
        $mobil = DB::table('mobil')->get();

        $supir = DB::table('supir')->get();

        return view('admin.manajemen.addkendaraan', compact('mobil', 'supir'));
    }

    public function store(Request $request)
    {
        $validation = $request->validate([
            'id_mobil' => 'required',
            'id_supir' => 'required',
        ]);

        $data =  DB::table('kendaraan')
            ->insert([
                'id_mobil' => $request->id_mobil,
                'id_supir' => $request->id_supir,
            ]);
        if ($data) {
            return redirect()->route('kendaraan')->with('success', 'Berhasil');
        } else {
            return redirect()->route('kendaraan')->with('error', 'Gagal');
        }
    }

    public function view()
    {
        return view('admin.manajemen.manajemenban');
    }
}
