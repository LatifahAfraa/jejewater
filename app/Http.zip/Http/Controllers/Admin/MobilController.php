<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MobilController extends Controller
{
    public function index()
    {
        $mobil = DB::table('mobil')->paginate(10);

        return view('admin.mobil.mobil', compact('mobil'));
    }

    public function add()
    {
        return view('admin.mobil.addmobil');
    }

    public function store(Request $request)
    {
        $validation = $request->validate([
            'nama_mobil' => 'required',
            'jenis_mobil' => 'required',
            'no_polisi' => 'required',
            'no_rangka' => 'required',
        ]);

        $data =  DB::table('mobil')
            ->insert([
                'nama_mobil' => $request->nama_mobil,
                'jenis_mobil' => $request->jenis_mobil,
                'no_polisi' => $request->no_polisi,
                'no_rangka' => $request->no_rangka,

            ]);
        if ($data) {
            return redirect()->route('mobil')->with('success', 'Berhasil');
        } else {
            return redirect()->route('mobil')->with('error', 'Gagal');
        }
    }

    public function delete($id_mobil)
    {
        DB::table('mobil')->where('id_mobil', $id_mobil)->delete();

        return redirect()->back();
    }

    public function edit($id_mobil)
    {
        $mobil = DB::table('mobil')->where('id_mobil', $id_mobil)->first();

        return view('admin.mobil.editmobil', compact('mobil'));
    }

    public function update(Request $request, $id_mobil)
    {
        $mobil = DB::table('mobil')->where('id_mobil', $id_mobil)->first();

        $validation = $request->validate([
            'nama_mobil' => 'required',
            'jenis_mobil' => 'required',
            'no_polisi' => 'required',
            'no_rangka' => 'required',
        ]);

        $data =  DB::table('mobil')
            ->where('id_mobil', $mobil->id_mobil)
            ->update([
                'nama_mobil' => $request->nama_mobil,
                'jenis_mobil' => $request->jenis_mobil,
                'no_polisi' => $request->no_polisi,
                'no_rangka' => $request->no_rangka,

            ]);
        if ($data) {
            return redirect()->route('mobil')->with('success', 'Berhasil Diupdate');
        } else {
            return redirect()->route('mobil')->with('error', 'Gagal');
        }
    }
}
