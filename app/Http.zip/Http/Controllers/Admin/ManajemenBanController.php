<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManajemenBanController extends Controller
{
    public function index()
    {
        $ban = DB::table('kendaraan')
            ->leftjoin('mobil', 'kendaraan.id_mobil', 'mobil.id_mobil')
            ->leftjoin('supir', 'kendaraan.id_supir', 'supir.id_supir')
            ->leftjoin('ban', 'kendaraan.id_ban', 'ban.id_ban')
            ->leftjoin('merk_ban', 'ban.merk_ban_id', 'merk_ban.merk_ban_id')
            ->select('kendaraan.*', 'mobil.*', 'supir.*', 'ban.*', 'merk_ban.*')
            ->paginate(10);

        $status = DB::table('ban')
            ->leftjoin('type_ban', 'ban.id_type', 'type_ban.id_type')
            ->leftjoin('status_ban', 'ban.id_status', 'status_ban.id_status')
            ->leftjoin('merk_ban', 'ban.merk_ban_id', 'merk_ban.merk_ban_id')
            ->select('ban.*', 'type_ban.*', 'status_ban.*', 'merk_ban.*')
            ->paginate(10);

        $kondisi = DB::table('ban')
            ->leftjoin('type_ban', 'ban.id_type', 'type_ban.id_type')
            ->leftjoin('kondisi_ban', 'ban.id_kondisi', 'kondisi_ban.id_kondisi')
            ->leftjoin('merk_ban', 'ban.merk_ban_id', 'merk_ban.merk_ban_id')
            ->select('ban.*', 'type_ban.*', 'kondisi_ban.*', 'merk_ban.*')
            ->paginate(10);

        return view('admin.manajemen.manajemenban', compact('ban', 'status', 'kondisi'));
    }

    public function add(Request $request, $id_kendaraan)
    {
        $kendaraan = DB::table('kendaraan')
            ->leftjoin('mobil', 'kendaraan.id_mobil', 'mobil.id_mobil')
            ->leftjoin('supir', 'kendaraan.id_supir', 'supir.id_supir')
            ->leftjoin('ban', 'kendaraan.id_ban', 'ban.id_ban')
            ->select('kendaraan.*', 'mobil.*', 'supir.*', 'ban.*')
            ->where('id_kendaraan', $id_kendaraan)
            ->first();

        $ban = DB::table('ban')
            ->leftjoin('type_ban', 'ban.id_type', 'type_ban.id_type')
            ->leftjoin('status_ban', 'ban.id_status', 'status_ban.id_status')
            ->leftjoin('kondisi_ban', 'ban.id_kondisi', 'kondisi_ban.id_kondisi')
            ->select('ban.*', 'type_ban.*', 'status_ban.*', 'kondisi_ban.*')
            ->where('status_ban.id_status', 1)
            ->get();


        return view('admin.manajemen.tambahban', compact('ban', 'kendaraan'));
    }

    public function store(Request $request, $id_kendaraan)
    {
        $kendaraan = DB::table('kendaraan')
            ->leftjoin('mobil', 'kendaraan.id_mobil', 'mobil.id_mobil')
            ->leftjoin('supir', 'kendaraan.id_supir', 'supir.id_supir')
            ->leftjoin('ban', 'kendaraan.id_ban', 'ban.id_ban')
            ->select('kendaraan.*', 'mobil.*', 'supir.*', 'ban.*')
            ->where('id_kendaraan', $id_kendaraan)
            ->first();

        $validation = $request->validate([
            'id_ban' => 'required',
            'tgl' => 'required',

        ]);

        $data =  DB::table('kendaraan')
            ->where('id_kendaraan', $kendaraan->id_kendaraan)
            ->update([
                'id_ban' => $request->id_ban,
                'tgl' => $request->tgl,

            ]);
        if ($data) {
            return redirect()->route('viewban')->with('success', 'Berhasil Pilih Ban');
        } else {
            return redirect()->route('viewban')->with('error', 'Gagal');
        }
    }

    public function accban($id_ban)
    {
        $kendaraan = DB::table('kendaraan')
            ->leftjoin('mobil', 'kendaraan.id_mobil', 'mobil.id_mobil')
            ->leftjoin('supir', 'kendaraan.id_supir', 'supir.id_supir')
            ->leftjoin('ban', 'kendaraan.id_ban', 'ban.id_ban')
            ->select('kendaraan.*', 'mobil.*', 'supir.*', 'ban.*')
            ->where('ban.id_ban', $id_ban)
            ->first();

        $data =  DB::table('ban')
            ->where('id_ban', $kendaraan->id_ban)
            ->update([
                'id_status' => 2,

            ]);

        if ($data) {
            return redirect()->route('viewban')->with('success', 'Berhasil, Ban Telah Digunakan');
        } else {
            return redirect()->route('viewban')->with('error', 'Gagal');
        }
    }

    public function copotban($id_ban)
    {
        $kendaraan = DB::table('kendaraan')
            ->leftjoin('mobil', 'kendaraan.id_mobil', 'mobil.id_mobil')
            ->leftjoin('supir', 'kendaraan.id_supir', 'supir.id_supir')
            ->leftjoin('ban', 'kendaraan.id_ban', 'ban.id_ban')
            ->select('kendaraan.*', 'mobil.*', 'supir.*', 'ban.*')
            ->where('ban.id_ban', $id_ban)
            ->first();

        $data =  DB::table('ban')
            ->where('id_ban', $kendaraan->id_ban)
            ->update([
                'id_status' => 1,

            ]);

        $data =  DB::table('kendaraan')
            ->where('id_ban', $kendaraan->id_ban)
            ->update([
                'id_ban' => NULL,

            ]);

        if ($data) {
            return redirect()->route('viewban')->with('success', 'Berhasil, Ban Telah Dicopot');
        } else {
            return redirect()->route('viewban')->with('error', 'Gagal');
        }
    }
}
