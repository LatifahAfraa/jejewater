@extends('template.master')
@section('title', 'Jeje Water - Home')
@section('content')
    <div class="content-body">
        <div class="container-fluid">
            <!-- row -->
            @if ($message = Session::get('success'))
                <div class="alert alert-success alert-dismissible fade show">
                    <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none"
                        stroke-linecap="round" stroke-linejoin="round" class="mr-2">
                        <polyline points="9 11 12 14 22 4"></polyline>
                        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                    </svg>
                    <strong>{{ $message }}</strong>
                    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                        <span><i class="mdi mdi-close"></i></span>
                    </button>
                </div>
            @endif

            @if ($message = Session::get('error'))
                <div class="alert alert-danger alert-dismissible fade show">
                    <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2"
                        fill="none" stroke-linecap="round" stroke-linejoin="round" class="mr-2">
                        <polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"></polygon>
                        <line x1="15" y1="9" x2="9" y2="15"></line>
                        <line x1="9" y1="9" x2="15" y2="15"></line>
                    </svg>
                    <strong>{{ $message }}</strong>
                    <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close">
                        <span><i class="mdi mdi-close"></i></span>
                    </button>
                </div>
            @endif
            <div class="row">
                <div class="col-xl-4 col-xxl-4 col-lg-12 col-sm-12">
                    <div class="widget-stat card bg-info">
                        <div class="card-body p-4">
                            <div class="media">
                                <span class="mr-3">
                                    <i class="fa fa-truck"></i>
                                </span>
                                <div class="media-body text-white text-right">
                                    <p class="mb-1">Jumlah Mobil</p>
                                    <h3 class="text-white">{{ $mobil }} Mobil</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-xxl-4 col-lg-12 col-sm-12">
                    <div class="widget-stat card bg-primary">
                        <div class="card-body p-4">
                            <div class="media">
                                <span class="mr-3">
                                    <i class="fa fa-user"></i>
                                </span>
                                <div class="media-body text-white text-right">
                                    <p class="mb-1">Jumlah Sopir</p>
                                    <h3 class="text-white">{{ $sopir }} Sopir</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-xxl-4 col-lg-12 col-sm-12">
                    <div class="widget-stat card bg-info">
                        <div class="card-body p-4">
                            <div class="media">
                                <span class="mr-3">
                                    <i class="fa fa-circle"></i>
                                </span>
                                <div class="media-body text-white text-right">
                                    <p class="mb-1">Jumlah Ban</p>
                                    <h3 class="text-white">{{ $ban }} Ban</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12 col-lg-12 col-xxl-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title"> Manajemen Ban</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-datatables">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>No Seri Ban</th>
                                            <th>Nama Ban</th>
                                            <th>Type Ban</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($aksi as $no => $data)
                                            <tr>
                                                <th>{{ $no + 1 }}</th>
                                                <td>{{ $data->no_seri_ban }}</td>
                                                <td>{{ $data->merk_ban_nama }}</td>
                                                <td>{{ $data->nama_type }}</td>
                                                <td>
                                                    @if ($data->id_status == 1)
                                                        <div class="d-flex">
                                                            <a href="{{ route('pasangban', $data->id_ban) }}"
                                                                class="btn btn-primary btn-sm px-4">Pasang Ban</a>
                                                        </div>
                                                    @else
                                                        <div class="d-flex">
                                                            <a href="#" class="btn btn-danger btn-sm px-4">Copot
                                                                Ban</a>
                                                        </div>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection('content')
@push('page-scripts')
    <script src="{{ asset('base/node_modules/sweetalert/dist/sweetalert.min.js') }}"></script>
@endpush
@push('after-scripts')
    <script>
        $(".swal-confirm").click(function(e) {
            id = e.target.dataset.id;
            swal({
                    title: 'Yakin hapus data?',
                    text: 'Data yang dihapus tidak bisa dikembalikan',
                    icon: 'warning',
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        swal('Data berhasil dihapus', {
                            icon: 'success',
                        });
                        $(`#delete${id}`).submit();
                    } else {
                        swal('Data batal dihapus');
                    }
                });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.table-datatables').DataTable({});
        });
    </script>
@endpush
