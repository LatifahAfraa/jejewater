@extends('template.master')
@section('title', 'Web Manajemen Ban - Edit Data Sopir')
@section('content')
    <div class="content-body">
        <div class="container-fluid">
            <div class="page-titles">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Master</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Edit Data Mobil</a></li>
                </ol>
            </div>
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Edit Data Mobil</h4>
                        </div>
                        <div class="card-body">
                            <div class="basic-form">
                                <form action="{{ route('updatemobil', $mobil->id_mobil) }}" method="POST">
                                    @csrf
                                    @method('patch')
                                    <label @error('nama_mobil') class="text-danger" @enderror>Nama Mobil
                                        @error('nama_mobil')
                                            {{ $message }}
                                        @enderror
                                    </label>
                                    <div class="input-group mb-3 ">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-truck"></i></span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Nama Mobil"
                                            name="nama_mobil" value="{{ $mobil->nama_mobil }}">
                                    </div>

                                    <label @error('jenis_mobil') class="text-danger" @enderror>Jenis Mobil
                                        @error('jenis_mobil')
                                            {{ $message }}
                                        @enderror
                                    </label>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-truck"></i></span>
                                        </div>
                                        <select name="jenis_mobil" id="" class="form-control"
                                            value="{{ $mobil->jenis_mobil }}">
                                            <option value="#">Pilih Jenis Mobil</option>
                                            <option value="Truck">Truck</option>
                                            <option value="Pickup">Pickup</option>
                                        </select>
                                    </div>

                                    <label @error('no_polisi') class="text-danger" @enderror>No Polisi
                                        @error('no_polis')
                                            {{ $message }}
                                        @enderror
                                    </label>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-id-card"></i></span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="No Polisi" name="no_polisi"
                                            value="{{ $mobil->no_polisi }}">
                                    </div>

                                    <label @error('no_rangka') class="text-danger" @enderror>No Rangka Mobil
                                        @error('no_rangka')
                                            {{ $message }}
                                        @enderror
                                    </label>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-id-card"></i></span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="No Rangka" name="no_rangka"
                                            value="{{ $mobil->no_rangka }}">
                                    </div>
                                    <div class="card-footer text-right">
                                        <button class="btn btn-rounded btn-primary" type="submit"
                                            id="toastr-success-top-right">Simpan</button>
                                        <a href="{{ route('mobil') }}" class="btn btn-rounded btn-secondary">Kembali</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
