@extends('template.master')
@section('title', 'Web Manajemen Ban - Manajemen Kendaraan')
@section('content')
    <div class="content-body">
        <div class="container-fluid">
            <div class="page-titles">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Manajemen</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Manajemen Kendaraan</a></li>
                </ol>
            </div>
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Manajemen Kendaraan</h4>
                        </div>
                        <div class="card-body">
                            <div class="basic-form">
                                <form action="{{ route('simpankendaraan') }}" method="POST">
                                    @csrf
                                    <label @error('id_mobil') class="text-danger" @enderror>Mobil
                                        @error('id_mobil')
                                            {{ $message }}
                                        @enderror
                                    </label>
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-th-list"></i></span>
                                        </div>
                                        <select name="id_mobil" class="form-control">
                                            <option value="">Pilih Mobil</option>
                                            @foreach ($mobil as $data)
                                                <option value="{{ $data->id_mobil }}">{{ $data->nama_mobil }}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <label @error('id_supir') class="text-danger" @enderror>Supir
                                        @error('id_supir')
                                            {{ $message }}
                                        @enderror
                                    </label>
                                    <div class="input-group ">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="fa fa-info"></i></span>
                                        </div>
                                        <select name="id_supir" class="form-control">
                                            <option value="">Pilih upir</option>
                                            @foreach ($supir as $data)
                                                <option value="{{ $data->id_supir }}">{{ $data->nama_supir }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="card-footer text-right">
                                        <button class="btn btn-rounded btn-primary" type="submit"
                                            id="toastr-success-top-right">Simpan</button>
                                        <a href="{{ route('kendaraan') }}" class="btn btn-rounded btn-secondary">Kembali</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
