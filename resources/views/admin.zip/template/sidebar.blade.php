<div class="deznav">
    <div class="deznav-scroll">
        <ul class="metismenu" id="menu">
            <li>
                <a href="{{ route('home') }}" class="ai-icon" aria-expanded="false">
                    <i class="flaticon-381-networking"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li>
                <a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-381-menu-1"></i>
                    <span class="nav-text">Master</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="{{ route('sopir') }}">Data Sopir</a></li>
                    <li><a href="{{ route('mobil') }}">Data Mobil</a></li>
                    <li><a href="{{ route('type') }}">Data Type Ban</a></li>
                    <li><a href="{{ url('admin/merk-ban') }}">Data Merk Ban</a></li>
                </ul>
            </li>
            <li>
                <a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-381-add-3"></i>
                    <span class="nav-text">Registrasi</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="{{ route('ban') }}">Registrasi Ban</a></li>
                    <!-- <li><a href="{{ route('kendaraan') }}">Registrasi Mobil</a></li> -->
                </ul>
            </li>
            <li>
                <a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-381-network"></i>
                    <span class="nav-text">Manajemen </span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="{{ route('viewban') }}">Manajemen Ban</a></li>
                </ul>
            </li>
        </ul>
    </div>
</div>
