<button type="button" class="btn btn-{{ $color }} text-white" data-toggle="modal"
    data-target="#modal{{ $id }}">
    {{ $name }}
</button>
